import './App.css'
import seal from './assets/seal.png'

function App() {

  const yourName = "Cyrus";

  const currentYear = 2026;


  return (

    <div className>

      <h1>Hello, React!</h1>

      <h2>My name is {yourName}</h2>

      <p>I’m learning React in {currentYear}.</p>

      <p>This is my first React component!</p>

      <img src={seal} alt="picture" width="200"></img>

      <h3>I am a excited to build...</h3>
<ul>
      <li>Apps</li>
      <li>Websites</li>
      <li>Capstone Project</li>
</ul>

  


    </div>

  );

}


export default App;
